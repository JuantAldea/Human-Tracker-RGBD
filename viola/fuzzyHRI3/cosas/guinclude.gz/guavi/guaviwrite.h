/***************************************************************************
                          guaviwrite.h  -  description
                             -------------------
    begin                : mi�ene 14 2004
    copyright            : (C) 2004 by 
    email                : 
 ***************************************************************************/

#ifndef GUAVIWRITE_H
#define GUAVIWRITE_H
#include <string>
#include <gu/guexception.h>
#include <guavi/revel.h>
using namespace std;
namespace guavi{
/** 
\brief This class allows to write easily avi files. It uses Revel library that is a wrapper for xvidcore 
*
* For that you have to
- 1) Set the required params with setParams()
- 2) open() the file where to save
- 3) add the frames with addFrame() 
- 4) close()
*
*Example:
\code
 GUAviWrite GAvi;
  GAvi.setParams(300,300,25); //images of 300x300 size and a video sequence of 25 frames per second
  GAvi.open(MyFilePath); //sets the file path
 for(int i=0;i<NumOfImages;i++) GAvi.addFrame(MyImages[i]); //add images
 Gavi.close();
\endcode
  *@author Rafael Munoz Salinas
  *@email rafaelmunozsalinas@decsai.ugr.es
*/


class GUAviWrite {
public:
  /**Empty constructor. Constroys an empty and invalid objet. It'll be necessary to call
  * setParams() and open() in order to use it
  *@see setParams()
  *@see isValid()
  *@see open()
  */
    GUAviWrite();
  /**Destuctor
  */
    ~GUAviWrite();
  /**Opens an video file for writing. If opening the file is not a valid video file
  * an exception is thrown. Aftern that it will be necessary to set the image Width and
  * Height before start to add frames to it
  *@param Path to the file to open
  *@see setParams()
  */
    void open(const string Path) throw(GUException);
  
  /**Indicates if the object is valid
  */
  bool isValid()const{return _isValid;}
  /**Indicates if the object is invalid
  *@see isValid()
  */
  bool operator!()const{return !isValid();}

  /** Set the value of the image width and height that will be passed to addFrame()
  *@param Width,Height of the frames that will be added
  *@param Fps number of Frames per second
  *@param Quality quality of the compresion if it's possible to use this parameter
  *@see addFrame()
  */
  void setParams(int Width,int Height,double Fps=30,int Quality=9600)throw(GUException);
  /**Adds the passed frame to the file. The image must have the size specified int setParams() and
  * could not be changed (always the same frame size)
  *@param data image with size getWidth()*getHeight()*3 with the image. The coded needs the data to be in the
  way B0,G0,R0,B1,G1,R1... If the data that you pass is not in that way but R0,G0,B0,R1... set swapBGR flag to true.
  *@param swapBGR indicates that the data must be swaped before.
  *@see setParams()
  */
  void addFrame(unsigned char *data,bool swapBGR=true)throw(GUException);
  /** Do the same than its homonim but only differs in the way tahat the parameters are passed
  *@param r red channel with size getWidth()*getHeight()
  *@param g green channel with size getWidth()*getHeight()
  *@param b blue channel with size getWidth()*getHeight()
  *@see setParams()
  */
  void addFrame(unsigned char *r,unsigned char *g,unsigned char *b)throw(GUException);
  /**Close the avi file and writes everything in disk
  */
  void close()throw(GUException);
  

  /**Returns width of each frame
  */
  int getWidth(){return width;}
  /**Returns height of each frame
  */
  int getHeight(){return height;}
  /**Returns the path of the file opened if any
  */
  string getPath()const{return path;}
  /**Returns the number of the current frame. This counter is increased when a frame is added
  */
  int getCurrentFrameIndex()const{return iCurrentFrameIndex;}
  /**Return the last frame inserted as a BGR buffer of size getWidth()*getHeight()*3.
  * the pointer returned is internally used so,don't delete it
  *@see getOutSize
  */
  const  unsigned char *  currentFrame()throw(GUException);
   /**Return the size of the image buffer as getWidth()*getHeight()*3
   */
  int  getOutSize(){return getWidth()*getHeight()*3;}

  /**Return the number of pixels of the image as getWidth()*getHeight()
  */
  int  getNumPixels(){return getWidth()*getHeight();}
  /**Returns the Fames per second the the avi file
  */
  double getFps()const{return fps;}
  /**Returns the wuality user by the compresion encoder
  */
  int getQuality()const{return 1000;}
 private:
  string path;
  int width,height,nPixels;
  double fps;
  unsigned int iCurrentFrameIndex;
  Revel_Error revError;
  Revel_Params revParams;
  Revel_VideoFrame frame;
  bool _isValid;
  unsigned char *pixelPtr;
  int encoderHandle;
};

};
#endif
