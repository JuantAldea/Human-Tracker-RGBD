/***************************************************************************
                          gucolor.h  -  description
                             -------------------
    begin                : mi� jul 28 2004
    copyright            : (C) 2004 by 
    email                : 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef GUCOLOR_H
#define GUCOLOR_H
#include <vector>
#include <iostream>
#include <string>
using namespace std;

/**This class is the base for all the types of colors supported by the library.
  *There supported the following colors:
  *
  * RGB, NormalizedRGB, HSV, YCbCr, YUV, YIQ, XYZD65, Lab, Luv, CMY, TSL, CIExy
  *
  * @author Rafael Munoz Salinas
  * @email salinas@decsai.ugr.es
  */
class GUColor {
public:
 /**Empty constructor. Creates a color with all the values set to -1
 */
	GUColor();
 /**Copy constructor
 */
	GUColor(const GUColor &GC);
 /**Parametrized constructor. Creates the object indicating the value of each component.
 *@param c1,c2,c3 components of the color
 *@param _type of color. Supported colors are RGB, NormalizedRGB, HSV,YCbCr,YUV,YIQ,XYZD65,Lab,Luv, CMY
 */
	GUColor(double c1,double c2,double c3,string _type)throw (string);
 /**Set the parameters of this object
 */
 void setParams(double c1,double c2,double c3,string _type)throw (string);
 /**Destructor
 */
	~GUColor();
  /**Access to the indicated component of the color
  */
  double & operator[](unsigned int index) throw(string);
  /**Assign operator
  */
  GUColor & operator=(const GUColor&) throw(string);
  /**Transform this color to the specified by the string identificator
  */
  GUColor to(string color) throw(string);
  /**Trasnform this color to RGB space and returns it
  */
  GUColor toRGB()  throw(string);
  /**Trasnform this color to normalized RGB space and returns it
  */
  GUColor toNormalizedRGB()  throw(string);
  /**Trasnform this color to HSV space and returns it
  */
  GUColor toHSV()  throw(string);
  /**Trasnform this color to YCrCb space and returns it
  */
  GUColor toYCbCr()  throw(string);
  /**Trasnform this color to YUV space and returns it
  */
  GUColor toYUV()  throw(string);
  /**Trasnform this color to YUV space and returns it
  */
  GUColor toYIQ()  throw(string);
  /**Trasnform this color to CIE XYZ where using Illuminant D65
  */
  GUColor toXYZD65()  throw(string);
  /**Trasnform this color to CIE Lab where using Illuminant D65
  */
  GUColor toLab()  throw(string);
  /**Trasnform this color to CIE Luv where using Illuminant D65
  */
  GUColor toLuv()  throw(string);
  /**Trasnform this color to CMY
  */
  GUColor toCMY()  throw(string);
  /**Transform this color to TSL
  */
  GUColor toTSL()  throw(string);
  
  /**
  */
  GUColor toCIExy() throw(string);
  /**Indicates the type of the color
  */
  string getType(){return type;}
  /**
  */
  friend ostream &operator<<(ostream &str,GUColor &c);
  /**Returns a chain to be readable about the contents of the object
  */
  string c_str();

private:
/**
*/
GUColor RGB2HSV(GUColor c)throw (string);
/**
*/
GUColor RGB2YCbCr(GUColor c)throw (string);
/**
*/
GUColor RGB2NormalizedRGB(GUColor c)throw (string);

/**
*/
GUColor RGB2YUV(GUColor c)throw (string);

/**
*/
GUColor RGB2YIQ(GUColor c)throw (string);

/**
*/
GUColor RGB2XYZD65(GUColor c)throw (string);

/**
*/
GUColor RGB2Lab(GUColor c)throw (string);

/**
*/
GUColor RGB2Luv(GUColor c)throw (string);

/**
*/
GUColor RGB2CMY(GUColor c)throw (string);

/**
*/
GUColor HSV2RGB(GUColor c)throw (string);
/**
*/
GUColor YCbCr2RGB(GUColor c)throw (string);

/**
*/
GUColor YUV2RGB(GUColor c)throw (string);

/**
*/
GUColor YIQ2RGB(GUColor c)throw (string);

/**
*/
GUColor XYZD652RGB(GUColor c)throw (string);

/**
*/
GUColor Lab2RGB(GUColor c)throw (string);

/**
*/
GUColor CMY2RGB(GUColor c)throw (string);

/**
*/
GUColor Luv2RGB(GUColor c)throw (string);

/**
*/
GUColor RGB2TSL(GUColor c)throw (string);

/**
*/
GUColor TSL2RGB(GUColor c)throw (string);

/**
*/
GUColor RGB2CIExy(GUColor c)throw (string);

/**
*/
GUColor CIExy2RGB(GUColor c)throw (string);
/**
*/
bool isValidType(string Type);
/**
*/
double toInt(double d);
/**Color components
*/
vector<double> components;
/**type of color{RGB,
*/
string type;

};


#endif
